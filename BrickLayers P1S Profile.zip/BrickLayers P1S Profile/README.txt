BrickLayers profile for the Bambu Lab P1S (Bambu Studio on Windows)
====================================================================

BrickLayers makes printed walls stronger. It shifts every other inner wall up
by half a layer, so the walls overlap like bricks and layers are harder to
split apart. It runs automatically on the G-code after Bambu Studio slices.


SETUP (once)
------------
1. If you don't have Python 3, install it from https://www.python.org/downloads/
   (the default options are fine).
2. Unzip this folder, then double-click "Install BrickLayers.bat".
   It copies BrickLayers to %LOCALAPPDATA%\BrickLayers and creates
   "0.20mm Standard @BBL X1C - BrickLayers.json" in this folder.
3. In Bambu Studio: File > Import > Import Configs... and pick that .json file.

The .json only works on the computer that ran the installer, because it
contains that computer's Python and BrickLayers locations.


PRINTING
--------
- Printer: "Bambu Lab P1S 0.4 nozzle".
  Process: "0.20mm Standard @BBL X1C - BrickLayers" (under User presets).
  Use any filament.
- Slice and print, or export, as usual. BrickLayers runs when the G-code is
  exported or sent, and a black window may flash briefly.
- The preview does NOT show the brick pattern. That's normal.
- The profile uses 6 walls, inner walls first, the Classic wall generator,
  and arc fitting off. Keep arc fitting off. BrickLayers only changes walls,
  not infill, so more walls means more benefit.
- Do a test print first. BrickLayers can add some stringing.


IF SOMETHING GOES WRONG
-----------------------
- "post-processing script does not exist" or a script error: Python was
  probably moved or updated. Run "Install BrickLayers.bat" again and
  re-import the new .json (say yes to replacing the old one).
- To stop using BrickLayers, pick a normal process preset.

BrickLayers is by GeekDetour: https://github.com/GeekDetour/BrickLayers
(GPL-3.0 license, see files\LICENSE).
