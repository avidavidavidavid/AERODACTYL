"""
Sets up BrickLayers for Bambu Studio and writes an importable P1S process preset.
Run through "Install BrickLayers.bat".

BrickLayers: https://github.com/GeekDetour/BrickLayers (GPL-3.0, see LICENSE)
"""
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent      # ...\files
PACKAGE = HERE.parent                        # the folder the user unzipped

PARENT = "0.20mm Standard @BBL X1C"          # Bambu's stock 0.20mm preset for the P1S
NAME = PARENT + " - BrickLayers"
BRICKLAYERS_ARGS = "-startAtLayer 3 -extrusionMultiplier 1.05 -enabled 1"

# What BrickLayers needs from the slicer, plus extra walls (it only changes walls).
SETTINGS = {
    "enable_arc_fitting": "0",
    "wall_generator": "classic",
    "wall_sequence": "inner wall/outer wall",
    "wall_loops": "6",
}


def bambu_version():
    """Installed Bambu Studio version (e.g. 2.9.1.70). The importer only needs a valid one."""
    conf = Path(os.environ.get("APPDATA", "")) / "BambuStudio" / "BambuStudio.conf"
    try:
        text = conf.read_text(encoding="utf-8", errors="replace")
        m = re.search(r'"version"\s*:\s*"(\d+)\.(\d+)\.(\d+)\.(\d+)"', text)
        if m:
            return ".".join(str(int(x)) for x in m.groups())
    except OSError:
        pass
    return "1.10.0.0"


def main():
    if sys.version_info < (3, 8):
        sys.exit(f"Python {sys.version.split()[0]} is too old. Install Python 3.8 or newer.")

    # 1) Copy BrickLayers to a fixed place, so this download folder can be deleted later.
    local = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    install_dir = Path(local) / "BrickLayers"
    install_dir.mkdir(parents=True, exist_ok=True)
    for name in ("bricklayers.py", "LICENSE"):
        shutil.copy2(HERE / name, install_dir / name)
    script = install_dir / "bricklayers.py"
    python = Path(sys.executable)

    # 2) Make sure it actually runs with this Python.
    check = subprocess.run([str(python), str(script), "-h"], capture_output=True, text=True)
    if check.returncode != 0:
        sys.exit("BrickLayers failed to start:\n" + (check.stderr or check.stdout)[-2000:])

    # 3) Write the preset. Bambu Studio runs this command after slicing and adds the
    #    G-code file path at the end. Full paths are required (no %VARIABLES%).
    preset = {
        "from": "User",
        "inherits": PARENT,
        "name": NAME,
        "print_settings_id": NAME,
        "version": bambu_version(),
        **SETTINGS,
        "post_process": [f'"{python}" "{script}" {BRICKLAYERS_ARGS}'],
    }
    out = PACKAGE / f"{NAME}.json"
    out.write_text(json.dumps(preset, indent=4) + "\n", encoding="utf-8")

    print("Done.")
    print(f"  BrickLayers installed to: {install_dir}")
    print(f"  Using Python:             {python}")
    print(f"  Profile created:          {out}")
    print()
    print("Next, in Bambu Studio:")
    print("  1. File > Import > Import Configs...  and pick the .json above.")
    print('  2. Printer "Bambu Lab P1S 0.4 nozzle", then process')
    print(f'     "{NAME}" (under User presets).')


if __name__ == "__main__":
    main()
