@echo off
rem Sets up BrickLayers for Bambu Studio and creates the P1S profile to import.
setlocal

if not exist "%~dp0files\make_profile.py" (
  echo Unzip the whole folder first, then run this from the unzipped folder.
  echo.
  pause
  exit /b 1
)

set "PYCMD="
py -3 -c "import sys" >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
  python -c "import sys" >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
  echo Python 3 was not found.
  echo Install it from https://www.python.org/downloads/ ^(default options are fine^),
  echo then run this again.
  echo.
  pause
  exit /b 1
)

%PYCMD% "%~dp0files\make_profile.py"
echo.
pause
